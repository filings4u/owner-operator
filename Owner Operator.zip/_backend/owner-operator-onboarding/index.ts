import { createClient } from "npm:@supabase/supabase-js@2";

const H={
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Headers":"authorization,apikey,content-type,x-client-info",
  "Access-Control-Allow-Methods":"POST,OPTIONS"
};
const J=(body:any,status=200)=>new Response(JSON.stringify(body),{status,headers:{...H,"Content-Type":"application/json","Cache-Control":"no-store"}});
const S=(v:any)=>String(v??"").trim();
const required=(obj:any,fields:string[])=>{for(const f of fields)if(!S(obj?.[f]))return f.replaceAll("_"," ")+" is required.";return null};
const ownerPlansWithTest=new Set(["owner_operator_plus","owner_operator_complete"]);

Deno.serve(async req=>{
  if(req.method==="OPTIONS")return new Response("ok",{headers:H});
  if(req.method!=="POST")return J({error:"Method not allowed."},405);
  try{
    const url=Deno.env.get("SUPABASE_URL")||"";
    const anon=Deno.env.get("SUPABASE_ANON_KEY")||"";
    const service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")||"";
    const token=(req.headers.get("Authorization")||"").replace(/^Bearer\s+/i,"").trim();
    if(!token)return J({error:"Authentication required."},401);

    const auth=createClient(url,anon,{auth:{persistSession:false,autoRefreshToken:false}});
    const db=createClient(url,service,{auth:{persistSession:false,autoRefreshToken:false}});
    const {data:ud,error:ue}=await auth.auth.getUser(token);
    if(ue||!ud.user)return J({error:"Authentication required."},401);

    const body=await req.json().catch(()=>({}));
    const action=S(body.action||"status");
    const sr=await fetch(url+"/functions/v1/owner-operator-session",{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":"Bearer "+token,"apikey":anon},
      body:JSON.stringify({
        portal_code:"owner_operator",
        membership_id:body.membership_id||undefined,
        subscription_id:body.subscription_id||undefined,
        page:"onboarding"
      })
    });
    const ctx=await sr.json().catch(()=>({}));
    if(!sr.ok||ctx.error)return J({error:ctx.error||"Owner-Operator access denied."},sr.status||403);
    if(ctx.requires_workspace_selection)return J(ctx);

    const owner=ctx.owner_operator||{};
    const org=ctx.organization||{};
    const employer=ctx.employer||{};
    const ownerId=owner.id;
    const employerId=employer.id||owner.employer_id||null;
    const tenantId=ctx.tenant_id;
    if(!ownerId||!tenantId||!org.id)return J({error:"Owner-Operator account context is incomplete."},409);

    const testIncluded=ctx.plan?.billing_model?.included_preemployment_dot_drug_test===true||ownerPlansWithTest.has(String(ctx.plan?.code||""));

    const getState=async()=>{
      const aq=await db.from("owner_operator_consortium_agreements").select("*").eq("owner_operator_id",ownerId).eq("status","accepted").order("signed_at",{ascending:false}).limit(1).maybeSingle();
      if(aq.error)throw aq.error;
      const dq=await db.from("dot_documents").select("*").eq("owner_operator_id",ownerId).eq("document_type","preemployment_negative_drug_test").is("archived_at",null).order("uploaded_at",{ascending:false}).limit(1).maybeSingle();
      if(dq.error)throw dq.error;
      const rq=await db.from("ctpa_dot_testing_requests").select("*").eq("owner_operator_id",ownerId).eq("source_type","owner_operator_onboarding").is("archived_at",null).order("created_at",{ascending:false}).limit(1).maybeSingle();
      if(rq.error)throw rq.error;
      let driver:any=null;
      if(employerId){
        const eq=await db.from("employees").select("*").eq("employer_id",employerId).eq("auth_user_id",ud.user.id).is("archived_at",null).limit(1).maybeSingle();
        if(eq.error)throw eq.error;
        driver=eq.data||null;
      }
      const preemploymentComplete=!!dq.data||!!rq.data;
      return {agreement:aq.data||null,proof:dq.data||null,request:rq.data||null,driver,preemploymentComplete,completed:!!aq.data&&preemploymentComplete};
    };

    if(action==="status"){
      const st=await getState();
      const meta=owner.metadata||{},driver=st.driver||{};
      return J({
        completed:st.completed,
        agreement_completed:!!st.agreement,
        preemployment_complete:st.preemploymentComplete,
        agreement:st.agreement,
        preemployment_proof:st.proof,
        test_request:st.request,
        test_included:testIncluded,
        purchase_url:"/checkout.html?service=dot_5_panel_urine",
        order_url:"/order-drug-test.html",
        prefill:{
          company_name:org.legal_name||owner.legal_name||employer.legal_name||"",
          authorized_name:[S(ud.user.user_metadata?.first_name),S(ud.user.user_metadata?.last_name)].filter(Boolean).join(" "),
          industry_code:S(employer.applicable_dot_agency||owner.regulatory_capacity?.agency||"FMCSA").toUpperCase(),
          plan_code:ctx.plan?.code||null,
          plan_name:ctx.plan?.name||null,
          plan_price:Number(ctx.plan?.monthly_price||ctx.plan?.billing_model?.amount||0),
          billing_frequency:ctx.subscription?.billing_frequency||ctx.plan?.billing_model?.frequency||"yearly",
          first_name:driver.first_name||meta.owner_first_name||ud.user.user_metadata?.first_name||"",
          last_name:driver.last_name||meta.owner_last_name||ud.user.user_metadata?.last_name||"",
          dot_number:owner.dot_number||employer.dot_number||"",
          mc_number:owner.mc_number||"",
          cdl_number:driver.cdl_number||meta.cdl_number||"",
          cdl_state:driver.cdl_state||meta.cdl_state||"",
          birthdate:driver.date_of_birth||"",
          cdl_address_line1:driver.address_line1||"",
          cdl_address_line2:driver.address_line2||"",
          cdl_city:driver.city||"",
          cdl_state_address:driver.state||"",
          cdl_postal_code:driver.postal_code||""
        }
      });
    }

    if(action==="complete_agreement"){
      const current=await getState();
      if(current.agreement)return J({ok:true,agreement:current.agreement,agreement_completed:true});
      const x=body.agreement||{};
      const industry=S(x.industry_code).toUpperCase();
      const allowed=["FMCSA","USCG","FRA","FAA","FTA","PHMSA","OTHER"];
      const miss=required(x,["company_name","initials_consortium","initials_preemployment","initials_quarterly_list","initials_roster_accuracy","initials_testing_duties","authorized_name","electronic_signature"]);
      if(miss)return J({error:miss},400);
      if(!allowed.includes(industry))return J({error:"Please select a valid DOT industry."},400);
      if(industry==="OTHER"&&!S(x.other_industry))return J({error:"Please identify the other industry."},400);
      if(x.accepted!==true)return J({error:"You must accept the Letter of Agreement before continuing."},400);
      const initials=[x.initials_consortium,x.initials_preemployment,x.initials_quarterly_list,x.initials_roster_accuracy,x.initials_testing_duties].map((v:any)=>S(v).replace(/[^A-Za-z]/g,"").slice(0,6).toUpperCase());
      if(initials.some((v:string)=>!v))return J({error:"Initial each required agreement section."},400);
      const signedAt=new Date().toISOString(),effective=signedAt.slice(0,10),expires=new Date(Date.now()+365*86400000).toISOString().slice(0,10);
      const snapshot={
        version:"owner_operator_consortium_v2",
        provider:{legal_name:"Workforce DOT, LLC",ownership:"A subsidiary of screenings4u, LLC",program_name:"Workforce DOT",address:"8537 S Pulaski Rd, Chicago, IL 60652",phone:"773-245-7009",fax:"773-850-8094"},
        terms:{applicable_rules:["49 CFR Part 40","49 CFR Part 382 and other applicable DOT agency rules"],term:"1 year with annual renewal while subscription remains active",preemployment_negative_required:true,quarterly_roster_confirmation:true},
        current_plan:{code:ctx.plan?.code||null,name:ctx.plan?.name||null,amount:Number(ctx.plan?.monthly_price||ctx.plan?.billing_model?.amount||0),frequency:ctx.subscription?.billing_frequency||ctx.plan?.billing_model?.frequency||"yearly",included_preemployment_dot_drug_test:testIncluded}
      };
      const ins=await db.from("owner_operator_consortium_agreements").insert({
        tenant_id:tenantId,organization_id:org.id,owner_operator_id:ownerId,employer_id:employerId,subscription_id:ctx.subscription?.id||null,user_id:ud.user.id,
        agreement_version:"owner_operator_consortium_v2",status:"accepted",company_name:S(x.company_name),industry_code:industry,other_industry:industry==="OTHER"?S(x.other_industry):null,
        initials_consortium:initials[0],initials_preemployment:initials[1],initials_quarterly_list:initials[2],initials_roster_accuracy:initials[3],initials_testing_duties:initials[4],
        authorized_name:S(x.authorized_name),authorized_title:S(x.authorized_title)||null,electronic_signature:S(x.electronic_signature),signed_at:signedAt,effective_date:effective,expires_on:expires,
        plan_code:ctx.plan?.code||null,plan_name:ctx.plan?.name||null,plan_price:Number(ctx.plan?.monthly_price||ctx.plan?.billing_model?.amount||0),plan_billing_frequency:ctx.subscription?.billing_frequency||ctx.plan?.billing_model?.frequency||"yearly",
        ip_address:S(req.headers.get("cf-connecting-ip")||req.headers.get("x-forwarded-for"))||null,user_agent:S(req.headers.get("user-agent"))||null,agreement_snapshot:snapshot,metadata:{source:"owner_operator_portal",portal_code:"owner_operator"}
      }).select("*").single();
      if(ins.error)throw ins.error;
      return J({ok:true,agreement:ins.data,agreement_completed:true,next_step:"/onboarding.html#preemployment"});
    }

    const st=await getState();
    if(!st.agreement)return J({error:"Complete the Consortium Letter of Agreement before the pre-employment testing step."},428);

    if(action==="upload_result"){
      const x=body.proof||{},mime=S(x.mime_type).toLowerCase(),testDate=S(x.test_date),fileName=S(x.file_name);
      if(!fileName||!testDate||!S(x.file_base64))return J({error:"Test date and an official PDF or image are required."},400);
      if(!["application/pdf","image/png","image/jpeg"].includes(mime))return J({error:"Upload a PDF, PNG, or JPEG file."},400);
      const td=new Date(testDate+"T00:00:00Z"),today=new Date();
      const age=Math.floor((Date.UTC(today.getUTCFullYear(),today.getUTCMonth(),today.getUTCDate())-td.getTime())/86400000);
      if(Number.isNaN(td.getTime())||age<0||age>30)return J({error:"The negative result must be dated within the last 30 days."},400);
      if(x.certified!==true)return J({error:"Certification of the official negative result is required."},400);
      let bytes:Uint8Array;
      try{bytes=Uint8Array.from(atob(S(x.file_base64)),c=>c.charCodeAt(0))}catch{return J({error:"The uploaded file could not be read."},400)}
      if(bytes.byteLength>10*1024*1024)return J({error:"The uploaded file must be 10 MB or smaller."},400);
      const id=crypto.randomUUID(),ext=mime==="application/pdf"?"pdf":mime==="image/png"?"png":"jpg",path=`owner-operators/${ownerId}/preemployment/${id}.${ext}`,ts=new Date().toISOString();
      const up=await db.storage.from("workforce-private").upload(path,bytes,{contentType:mime,upsert:false});if(up.error)throw up.error;
      const ins=await db.from("dot_documents").insert({id,tenant_id:tenantId,employer_id:employerId,owner_operator_id:ownerId,document_type:"preemployment_negative_drug_test",storage_bucket:"workforce-private",storage_path:path,file_name:fileName,mime_type:mime,size_bytes:bytes.byteLength,uploaded_by:ud.user.id,uploaded_at:ts,access_level:"restricted",title:"Pre-Employment Negative DOT Drug Test",document_status:"pending_review",recipient_type:"owner_operator",recipient_id:ownerId,recipient_name:owner.legal_name||org.legal_name||null,recipient_email:ud.user.email||null,metadata:{test_date:testDate,negative_result_certified:true,verification_status:"pending_review",source:"owner_operator_onboarding",subscription_id:ctx.subscription?.id||null},updated_at:ts}).select("*").single();
      if(ins.error)throw ins.error;
      return J({ok:true,completed:true,proof:ins.data,next_step:"/dashboard.html"});
    }

    if(action==="create_test_order"){
      if(!testIncluded)return J({error:"A pre-employment DOT drug test is not included in this subscription.",purchase_required:true,purchase_url:"/checkout.html?service=dot_5_panel_urine"},402);
      if(st.request)return J({ok:true,completed:true,request:st.request,already_ordered:true,next_step:"/dashboard.html"});
      const x=body.order||{};
      const miss=required(x,["first_name","last_name","dot_number","cdl_number","cdl_state","birthdate","cdl_address_line1","cdl_city","cdl_state_address","cdl_postal_code","current_address_line1","current_city","current_state","current_postal_code"]);
      if(miss)return J({error:miss},400);
      const ts=new Date().toISOString(),id=crypto.randomUUID(),num="OOP-"+Date.now().toString(36).toUpperCase()+"-"+id.slice(0,6).toUpperCase();
      const ins=await db.from("ctpa_dot_testing_requests").insert({
        id,request_number:num,tenant_id:tenantId,ctpa_id:null,employer_id:employerId,employee_id:st.driver?.id||null,owner_operator_id:ownerId,program_id:null,
        source_type:"owner_operator_onboarding",dot_agency:S(owner.regulatory_capacity?.agency||employer.applicable_dot_agency||"FMCSA").toUpperCase(),service_code:"dot_5_panel_urine",test_type:"drug",status:"submitted",
        requested_by_user_id:ud.user.id,submitted_at:ts,notes:"Included pre-employment DOT 5-panel urine drug test requested during Owner-Operator onboarding.",
        metadata:{included_by_subscription:true,subscription_id:ctx.subscription?.id||null,plan_code:ctx.plan?.code||null,donor:{first_name:S(x.first_name),last_name:S(x.last_name),birthdate:S(x.birthdate),cdl_number:S(x.cdl_number),cdl_state:S(x.cdl_state)},company:{dot_number:S(x.dot_number),mc_number:S(x.mc_number)||null},cdl_address:{line1:S(x.cdl_address_line1),line2:S(x.cdl_address_line2)||null,city:S(x.cdl_city),state:S(x.cdl_state_address),postal_code:S(x.cdl_postal_code)},current_location:{line1:S(x.current_address_line1),line2:S(x.current_address_line2)||null,city:S(x.current_city),state:S(x.current_state),postal_code:S(x.current_postal_code)},scheduling_instruction:"Use the current/future location to identify the closest available collection site."},created_at:ts,updated_at:ts
      }).select("*").single();
      if(ins.error)throw ins.error;
      return J({ok:true,completed:true,request:ins.data,next_step:"/dashboard.html"});
    }

    return J({error:"Unsupported onboarding action."},400);
  }catch(e){console.error("owner-operator-onboarding",e);return J({error:e instanceof Error?e.message:String(e)},500)}
});
