Owner-Operator support routing update
- Owner-Operator support tickets route through workforce-support v18.
- Tickets are written to support_tickets so DOT Management can receive them.
- Branded customer confirmation email is sent on ticket creation.
- Branded admin notification is sent to owner-operator@screenings4u.com.
- Support contact email updated to owner-operator@screenings4u.com.
