Owner-Operator onboarding backend
================================

New Edge Function required by the pre-employment onboarding UI:
  owner-operator-onboarding

Source:
  _backend/owner-operator-onboarding/index.ts

Actions used by the portal:
  status
  complete_agreement
  upload_result
  create_test_order

The function uses the existing owner-operator-session function for authorization and uses the Supabase service role server-side for private document upload and testing-request creation.

Expected Supabase secrets already used elsewhere in this project:
  SUPABASE_URL
  SUPABASE_ANON_KEY
  SUPABASE_SERVICE_ROLE_KEY

Live database/catalog changes already made in project elpbnytpciqnbexiaebp:
- owner_operator_essential: included_preemployment_dot_drug_test=false, credits=0
- owner_operator_plus: included_preemployment_dot_drug_test=true, credits=1
- owner_operator_complete: included_preemployment_dot_drug_test=true, credits=1
- New service: dot_5_panel_urine / DOT 5-Panel Urine Drug Test / $59.95 one-time
- Seller metadata: Workforce DOT, LLC; owned by screenings4u, LLC
- Non-included test purchase URL: /checkout.html?service=dot_5_panel_urine

Important:
The frontend package calls /functions/v1/owner-operator-onboarding. Deploy this Edge Function before publishing the updated portal frontend.
