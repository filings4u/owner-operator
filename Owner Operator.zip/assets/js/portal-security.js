(()=>{'use strict';
const P=location.pathname.split('/').pop()?.toLowerCase()||'index.html';
if(['login.html','auth-handoff.html','workspace.html','404.html','forgot-password.html','reset-password.html'].includes(P)){document.documentElement.classList.remove('s4u-auth-pending');return}
const C=window.PORTAL_CONFIG||window.S4U||{};const URL=C.workforceUrl||C.url;const KEY=C.workforceKey||C.key;const CODE=C.portalCode||C.portal_code;
const IDLE=10*60*1000,WARN=60*1000,KEY_LAST='s4u_idle_last:'+location.hostname,BOOT_KEY='s4u_owner_bootstrap_cache',BOOT_TTL=120000;let last=Date.now(),warnOpen=false,timer=null,countTimer=null,lastActivityWrite=0;
const sb=window.S4UGetSupabaseClient?.();
function safeLast(){const n=Number(localStorage.getItem(KEY_LAST)||0);return Number.isFinite(n)&&n>0?n:last}
function setLast(){last=Date.now();try{localStorage.setItem(KEY_LAST,String(last))}catch{};hideWarn();schedule()}
function modal(){let m=document.getElementById('s4u-idle-modal');if(m)return m;m=document.createElement('div');m.id='s4u-idle-modal';m.innerHTML='<div class="s4u-idle-card" role="dialog" aria-modal="true" aria-labelledby="s4u-idle-title"><div class="s4u-idle-mark">screenings4u</div><h2 id="s4u-idle-title">Your session is about to expire</h2><p>For your security, you will be signed out after 10 minutes of inactivity.</p><div class="s4u-idle-count"><strong id="s4u-idle-seconds">60</strong><span>seconds remaining</span></div><div class="s4u-idle-actions"><button id="s4u-stay" type="button">Stay Logged In</button><button id="s4u-signout" type="button">Sign Out Now</button></div></div>';document.body.appendChild(m);m.querySelector('#s4u-stay').onclick=setLast;m.querySelector('#s4u-signout').onclick=logout;return m}
function showWarn(){if(warnOpen)return;warnOpen=true;const m=modal();m.classList.add('open');let left=Math.max(0,Math.ceil((IDLE-(Date.now()-safeLast()))/1000));const el=m.querySelector('#s4u-idle-seconds');el.textContent=String(left);clearInterval(countTimer);countTimer=setInterval(()=>{left=Math.max(0,Math.ceil((IDLE-(Date.now()-safeLast()))/1000));el.textContent=String(left);if(left<=0)logout()},250)}
function hideWarn(){warnOpen=false;document.getElementById('s4u-idle-modal')?.classList.remove('open');clearInterval(countTimer)}
async function logout(){clearTimeout(timer);clearInterval(countTimer);try{await sb?.auth.signOut()}catch{};try{Object.keys(localStorage).filter(k=>k.startsWith('s4u_')||k.startsWith('sb-')).forEach(k=>localStorage.removeItem(k))}catch{};location.replace('/login.html?reason=inactive')}
function schedule(){clearTimeout(timer);const age=Date.now()-safeLast();if(age>=IDLE){logout();return}if(age>=IDLE-WARN){showWarn();timer=setTimeout(schedule,1000);return}hideWarn();timer=setTimeout(schedule,Math.max(1000,(IDLE-WARN)-age))}
function bindActivity(){const mark=()=>{const now=Date.now();if(warnOpen||now-lastActivityWrite<5000)return;lastActivityWrite=now;setLast()};['pointerdown','keydown','touchstart','scroll'].forEach(ev=>addEventListener(ev,mark,{passive:true}));addEventListener('storage',e=>{if(e.key===KEY_LAST){last=safeLast();hideWarn();schedule()}})}
async function guard(){
  if(!sb||!URL||!KEY||!CODE){location.replace('/login.html?reason=config');return}
  let {data:{session},error}=await sb.auth.getSession();
  if(error||!session){location.replace('/login.html?reason=session');return}
  const signInMs=Date.parse(session.user?.last_sign_in_at||'')||0;
  const storedLast=safeLast();
  if(!storedLast||storedLast<signInMs){last=Date.now();try{localStorage.setItem(KEY_LAST,String(last))}catch{}}

  const refreshSession=async()=>{
    const rr=await sb.auth.refreshSession();
    if(rr.error||!rr.data?.session)return false;
    session=rr.data.session;
    last=Date.now();try{localStorage.setItem(KEY_LAST,String(last))}catch{}
    return true;
  };

  const requestContext=async()=>{
    const membership=localStorage.getItem('s4u_'+CODE+'_membership')||'';
    const subscription=localStorage.getItem('s4u_'+CODE+'_subscription')||'';
    const r=await fetch(URL+'/functions/v1/owner-operator-bootstrap',{
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':'Bearer '+session.access_token,'apikey':KEY},
      body:JSON.stringify(window.S4UWithPortal({portal_code:CODE,membership_id:membership||undefined,subscription_id:subscription||undefined,page:P.replace('.html','')}))
    });
    let d=await r.json().catch(()=>({}));
    if(r.status===401&&await refreshSession()){
      const retry=await fetch(URL+'/functions/v1/owner-operator-bootstrap',{
        method:'POST',
        headers:{'Content-Type':'application/json','Authorization':'Bearer '+session.access_token,'apikey':KEY},
        body:JSON.stringify(window.S4UWithPortal({portal_code:CODE,membership_id:membership||undefined,subscription_id:subscription||undefined,page:P.replace('.html','')}))
      });
      d=await retry.json().catch(()=>({}));
      return {r:retry,d};
    }
    return {r,d};
  };

  let r={ok:true,status:200},d=null;
  try{
    const cached=JSON.parse(sessionStorage.getItem(BOOT_KEY)||'null');
    if(cached&&cached.user_id===session.user.id&&Date.now()-Number(cached.ts||0)<BOOT_TTL)d=cached.data||null;
  }catch{}
  if(!d){
    ({r,d}=await requestContext());
    if(r.ok&&!d?.error){try{sessionStorage.setItem(BOOT_KEY,JSON.stringify({ts:Date.now(),user_id:session.user.id,data:d}))}catch{}}
  }

  // Owner-Operator is a single-organization portal. If the backend returns more
  // than one eligible subscription/workspace, select the strongest active plan
  // automatically instead of sending the user to a workspace page that does not
  // exist in this portal.
  if(d.requires_workspace_selection&&Array.isArray(d.workspaces)&&d.workspaces.length){
    const rank=w=>{
      const code=String(w?.plan_code||'').toLowerCase();
      if(code.endsWith('_complete'))return 30;
      if(code.endsWith('_plus'))return 20;
      if(code.endsWith('_essential'))return 10;
      return 0;
    };
    const chosen=[...d.workspaces].sort((a,b)=>rank(b)-rank(a))[0];
    try{
      if(chosen?.membership_id)localStorage.setItem('s4u_'+CODE+'_membership',chosen.membership_id);
      if(chosen?.subscription_id)localStorage.setItem('s4u_'+CODE+'_subscription',chosen.subscription_id);
    }catch{}
    try{sessionStorage.removeItem(BOOT_KEY)}catch{}
    ({r,d}=await requestContext());
    if(r.ok&&!d?.error){try{sessionStorage.setItem(BOOT_KEY,JSON.stringify({ts:Date.now(),user_id:session.user.id,data:d}))}catch{}}
  }

  if(d.requires_workspace_selection){
    document.documentElement.classList.remove('s4u-auth-pending');
    document.body.innerHTML='<main class="login-card"><h1>Portal unavailable</h1><p>We could not select your Owner-Operator subscription automatically. Please sign out and sign back in, or contact support.</p><a class="btn primary" href="/login.html">Return to sign in</a></main>';
    return;
  }
  if(!r.ok||d.error||d.has_access===false){
    if(r.status===401){try{await sb.auth.signOut()}catch{};location.replace('/login.html?reason=session');return}
    document.documentElement.classList.remove('s4u-auth-pending');
    document.body.innerHTML='<main class="login-card"><h1>Portal unavailable</h1><p>'+String(d.error||d.reason||'Unable to verify portal access.')+'</p><a class="btn primary" href="/login.html">Return to sign in</a></main>';
    return;
  }
  last=safeLast();
  if(!last||last<(Date.parse(session.user?.last_sign_in_at||'')||0)){last=Date.now();try{localStorage.setItem(KEY_LAST,String(last))}catch{}}
  if(Date.now()-last>=IDLE){await logout();return}
  try{localStorage.setItem(KEY_LAST,String(last))}catch{}
  window.__S4U_OWNER_BOOTSTRAP__=d;window.__S4U_OWNER_AUTH_CONTEXT__=d.context||d;bindActivity();schedule();document.documentElement.classList.remove('s4u-auth-pending');window.dispatchEvent(new CustomEvent('s4u:dot-authenticated',{detail:d.context||d}))
}
const css=document.createElement('style');css.textContent='#s4u-idle-modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(5,18,35,.72);z-index:2147483647;padding:20px}#s4u-idle-modal.open{display:flex}.s4u-idle-card{width:min(460px,100%);background:#fff;border-radius:18px;padding:28px;box-shadow:0 28px 80px rgba(0,0,0,.28);font-family:Arial,sans-serif;color:#102f55}.s4u-idle-mark{font-size:0.857143rem;font-weight:900;letter-spacing:.08em;color:#ff6b00;text-transform:uppercase}.s4u-idle-card h2{font-size:1.714286rem;margin:10px 0}.s4u-idle-card p{font-size:1rem;line-height:1.55;color:#516174}.s4u-idle-count{display:flex;align-items:baseline;gap:9px;margin:20px 0}.s4u-idle-count strong{font-size:2.571429rem}.s4u-idle-count span{font-size:0.857143rem;color:#6b7788}.s4u-idle-actions{display:flex;gap:10px}.s4u-idle-actions button{flex:1;border:0;border-radius:10px;padding:12px 14px;font-weight:800;cursor:pointer}.s4u-idle-actions button:first-child{background:#102f55;color:#fff}.s4u-idle-actions button:last-child{background:#eef2f6;color:#102f55}';document.head.appendChild(css);
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',guard,{once:true});else guard();
})();